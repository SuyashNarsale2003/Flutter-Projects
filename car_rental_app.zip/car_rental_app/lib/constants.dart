import 'package:flutter/material.dart';

Color backgroundColor = const Color(0xFF40ac9c);

Color cardColor = const Color(0xFF203e5a);
