import 'dart:async';

import 'package:flutter/material.dart';
import 'package:todo_project/list_page.dart';

class Start_page extends StatefulWidget {
  const Start_page({super.key});
  @override
  @override
  State<Start_page> createState() => _Start_pageState();
}

class _Start_pageState extends State<Start_page> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 3), () {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: ((context) => List_page())));
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              height: 100,
              width: 100,
              'https://static.vecteezy.com/system/resources/previews/019/519/243/original/to-do-list-icon-for-your-website-mobile-presentation-and-logo-design-free-vector.jpg',
            ),
            Text(
              "TO-DO",
            )
          ],
        ),
      ),
    );
  }
}
