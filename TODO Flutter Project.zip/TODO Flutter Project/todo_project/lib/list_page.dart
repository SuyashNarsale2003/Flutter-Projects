import "package:flutter/material.dart";

// ignore: camel_case_types
class List_page extends StatefulWidget {
  const List_page({super.key});

  @override
  State<List_page> createState() => _List_pageState();
}

List<String> myList = [];

// ignore: camel_case_types
class _List_pageState extends State<List_page> {
  final myController = TextEditingController();
  bool x = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 204, 132, 217),
      appBar: AppBar(
        elevation: 15,
        shadowColor: const Color.fromARGB(255, 128, 28, 104),
        backgroundColor: const Color.fromARGB(255, 141, 32, 160),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.calendar_month_outlined,
              color: Colors.white,
              size: 40,
            ),
            Container(
              width: 5,
            ),
            const Text("TO-DO",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 5,
                  fontSize: 30,
                ))
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
              context: context,
              builder: (context) {
                return AlertDialog(
                  alignment: Alignment.center,
                  scrollable: true,
                  title: const Text(
                    "ADD TASK",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  content: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TextField(
                          textAlign: TextAlign.center,
                          controller: myController,
                          decoration: const InputDecoration(
                              hintText: "Enter Task",
                              border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(30))))),
                      Container(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  myList.add(myController.text);
                                  myController.clear();
                                  Navigator.of(context).pop();
                                });
                              },
                              child: const Icon(
                                Icons.add,
                              )),
                          Container(
                            width: 15,
                          ),
                          ElevatedButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: const Icon(Icons.cancel)),
                        ],
                      )
                    ],
                  ),
                );
              });
        },
        backgroundColor: Colors.white,
        child: const Icon(
          Icons.add_box,
          color: Color.fromARGB(255, 141, 32, 160),
        ),
      ),
      body: ListView.builder(
        itemCount: myList.length,
        padding: const EdgeInsets.only(top: 35, left: 50, right: 50),
        itemBuilder: (BuildContext context, int index) {
          return Column(
            children: [
              ListTile(
                titleTextStyle:
                    const TextStyle(color: Colors.white, fontSize: 20),
                leading: Text("${index + 1}.",
                    style: const TextStyle(color: Colors.white, fontSize: 20)),
                title: Text(
                  myList[index],
                  style: const TextStyle(fontSize: 23, color: Colors.white),
                ),
                titleAlignment: ListTileTitleAlignment.center,
                tileColor: const Color.fromARGB(255, 141, 32, 160),
                trailing: IconButton(
                  icon: const Icon(
                    Icons.done,
                    color: Color.fromARGB(255, 224, 157, 236),
                  ),
                  onPressed: () {
                    setState(() {
                      myList.removeAt(index);
                    });
                  },
                ),
              ),
              Container(
                height: 12,
              )
            ],
          );
        },
      ),
    );
  }
}
