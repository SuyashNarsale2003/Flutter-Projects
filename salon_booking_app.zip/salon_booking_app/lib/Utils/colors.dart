import 'package:flutter/material.dart';

Color primaryColor = const Color(0xffA884C5);
Color secondaryColor = const Color(0xffF9C0EA);
Color textColor = const Color(0xff415C77);
