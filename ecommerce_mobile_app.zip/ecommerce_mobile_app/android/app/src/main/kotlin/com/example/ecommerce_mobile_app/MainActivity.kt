package com.example.ecommerce_mobile_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
